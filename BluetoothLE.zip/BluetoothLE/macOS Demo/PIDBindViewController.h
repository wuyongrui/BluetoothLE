//
//  PIDBindViewController.h
//  macOS Demo
//
//  Created by 吴勇锐 on 2017/12/18.
//  Copyright © 2017年 midmirror. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface PIDBindViewController : NSViewController

@end
